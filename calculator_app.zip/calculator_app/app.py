from flask import Flask, render_template, request

app = Flask(__name__)

# Route for the home page and calculator
@app.route('/', methods=['GET', 'POST'])
def calculator():
    result = ''
    if request.method == 'POST':
        # Get the expression from the form
        expression = request.form['expression']

        try:
            # Calculate the result using Python's eval function
            result = str(eval(expression))
        except Exception as e:
            result = 'Error: ' + str(e)

    # Render the template with the result
    return render_template('index.html', result=result)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=4000, debug=True)